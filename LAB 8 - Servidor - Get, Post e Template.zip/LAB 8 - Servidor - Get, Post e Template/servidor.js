var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');

var app = express();
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: false}))
app.use(bodyParser.json())
app.set('view engine', 'ejs')
app.set('views', './views');

var server = http.createServer(app);
server.listen(80);

console.log('Servidor rodando ...'.rainbow);

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Login.html'));
});

app.get('/cadastro',function (requisicao, resposta){
var Email = requisicao.query.Email;
var Senha = requisicao.query.Senha;
var nome = requisicao.query.nome;
var nascimento = requisicao.query.nascimento;

resposta.render('resposta', {Email,Senha,nome,nascimento})
})
